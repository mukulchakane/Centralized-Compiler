public class MainClass2 {
	public MainClass2() {
		;
	}

	public void foo2() {
		;
	}
	
	public void bar2() {
		;
	}
}
