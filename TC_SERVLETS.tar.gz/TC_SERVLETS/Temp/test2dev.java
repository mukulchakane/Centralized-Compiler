#include<stdio.h>
#include<conio.h>
void main()
{
	printf("Hello");
	getch();
}
