public class UmeshClass{
	public UmeshClass() {
		;
	}
	

	public void foo() {
		;
	}
	
	public void bar() {
		;
	}
	
	public static void main(String args[]) {
		int i, j, k;
		i = 6;
		j = 999;
		k = j / 187;
		System.out.println("k = " + (k));
	}
	
}
