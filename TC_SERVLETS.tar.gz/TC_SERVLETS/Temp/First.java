import java.lang.*;
public class First 
{
  
	public static void main(String arg[])
	{
	//First m=new First();
 System.out.println("First Prog.");
	}
}
