public class MyClass {
	public MyClass() {
		;
	}
	

	public void foo() {
		;
	}
	
	public void bar() {
		;
	}
	
	public static void main(String args[]) {
		int i, j, k;
		i = 4;
		j = 6;
		k = 5;
		System.out.println("k = " + k);
	}
	
}
