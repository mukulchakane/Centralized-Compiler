public class Myclass{
	public MyClass() {
		;
	}
	

	public void foo() {
		;
	}
	
	public void bar() {
		;
	}
	
	public static void main(String args[]) {
		int i, j, k;
		i = 6;
		j = 999;
		k = j / 0;
		System.out.println("k = " + (k));
	}
	
}
