public class kk{
public static void main(String args[]) {
System.out.println("kkkkkkkkkkkkkkkkkkkkkkkkk");
}
}