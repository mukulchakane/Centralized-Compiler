
void main()
{
	printf("Hello");
	getch();
}
