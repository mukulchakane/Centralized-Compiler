public class MyClass2 {

	;//public MyClass m1;

	public MyClass2() {
		;//m1 = new MyClass();
	}
	

	public void foo() {
		;
	}
	
	public void bar() {
		;
	}
	
	public static void main(String args[]) {
		int i, j, k;
		i = 4;
		j = 6;
		k = 7 / 2;
		System.out.println("k = " + k);
	}
	
}
