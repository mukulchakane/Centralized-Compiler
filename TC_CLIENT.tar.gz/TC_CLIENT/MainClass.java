public class MainClass {

	public MainClass() {
		;
	}

}
