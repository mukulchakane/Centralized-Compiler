/*
 * Client.java
 *
 * 
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tc_Pack;

import java.io.Serializable;

/**
 *
 * 
 */
public class Client implements Serializable {
    public String clientNo;
    public String password;
    public String userAlias;
    public String task;
    
    public Client() {
    }
    
}
